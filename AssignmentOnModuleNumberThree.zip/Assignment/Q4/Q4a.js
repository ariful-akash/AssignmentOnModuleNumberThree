function openNewWindow(url, width, height) {
    // Calculate the position to center the window on the screen
    var left = (screen.width - width) / 2;
    var top = (screen.height - height) / 2;
  
    // Open the new window
    window.open(url, "_blank", "width=" + width + ", height=" + height + ", top=" + top + ", left=" + left);
  }
  openNewWindow("https://www.example.com", 800, 600);