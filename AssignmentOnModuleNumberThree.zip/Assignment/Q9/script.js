document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
  
    // Clear previous error messages
    clearErrors();
  
    // Validate form fields
    var nameInput = document.getElementById('name');
    var emailInput = document.getElementById('email');
    var passwordInput = document.getElementById('password');
    var confirmPasswordInput = document.getElementById('confirmPassword');
  
    var nameError = document.getElementById('nameError');
    var emailError = document.getElementById('emailError');
    var passwordError = document.getElementById('passwordError');
    var confirmPasswordError = document.getElementById('confirmPasswordError');
  
    var isValid = true;
  
    // Validate name field
    if (nameInput.value.trim() === '' || !isLettersOnly(nameInput.value)) {
      nameError.textContent = 'Name is required and should contain only letters';
      isValid = false;
    }
  
    // Validate email field
    if (!isValidEmail(emailInput.value)) {
      emailError.textContent = 'Email is not valid';
      isValid = false;
    }
  
    // Validate password field
    if (!isValidPassword(passwordInput.value)) {
      passwordError.textContent = 'Password should have a minimum length of 8 characters, contain at least one uppercase letter, one lowercase letter, and one digit';
      isValid = false;
    }
  
    // Validate confirm password field
    if (confirmPasswordInput.value !== passwordInput.value) {
      confirmPasswordError.textContent = 'Passwords do not match';
      isValid = false;
    }
  
    if (isValid) {
      // Form is valid, you can submit the form or perform further actions here
      alert('Form submitted successfully!');
      // Reset form fields
      document.getElementById('myForm').reset();
    }
  });
  
  function isLettersOnly(str) {
    return /^[A-Za-z]+$/.test(str);
  }
  
  function isValidEmail(email) {
    // Regular expression for email validation
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  function isValidPassword(password) {
    // Regular expression for password validation
    var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    return passwordRegex.test(password);
  }
  
  function clearErrors() {
    var errorElements = document.getElementsByClassName('error');
    for (var i = 0; i < errorElements.length; i++) {
      errorElements[i].textContent = '';
    }
  }