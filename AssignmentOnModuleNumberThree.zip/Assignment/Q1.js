function getDay(dateString) {
    const date = new Date(dateString);
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayOfWeekIndex = date.getDay();
    const dayOfWeek = daysOfWeek[dayOfWeekIndex];
    return dayOfWeek;
  }
  function display(day){
    this.day = day;
    console.log(day);
  }

const date = '2023-06-20';
const dayOfWeek = getDay(date);
display(dayOfWeek);