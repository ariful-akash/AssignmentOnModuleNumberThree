function changeImageSource() {
    var image = document.getElementById("myImage");
    image.src = "js.png";
    image.alt = "New Image Not Found";
}