function squareRoot(numbers) {
    const sumOfSquares = numbers.reduce((sum, num) => sum + Math.pow(num, 2), 0);
    const squareRoot = Math.sqrt(sumOfSquares);
    return squareRoot;
}

function display(result){
    this.result = result;
    console.log(result);
  }
const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const result = squareRoot(numbers);
display(result);