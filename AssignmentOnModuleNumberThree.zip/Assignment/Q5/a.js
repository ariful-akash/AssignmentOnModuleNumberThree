
    function getBrowserInfo() {
      var userAgent = navigator.userAgent;
      var browserName = '';
      var browserVersion = '';

      // Check for Chrome
      if (/Chrome/.test(userAgent) && /Google Inc/.test(navigator.vendor)) {
        browserName = 'Google Chrome';
        browserVersion = userAgent.substring(userAgent.indexOf('Chrome') + 7);
      }
      // Check for Firefox
      else if (/Firefox/.test(userAgent)) {
        browserName = 'Mozilla Firefox';
        browserVersion = userAgent.substring(userAgent.indexOf('Firefox') + 8);
      }
      // Check for Safari
      else if (/Safari/.test(userAgent) && /Apple Computer/.test(navigator.vendor)) {
        browserName = 'Apple Safari';
        browserVersion = userAgent.substring(userAgent.indexOf('Version') + 8);
      }
      // Check for Opera
      else if (/Opera/.test(userAgent) || /OPR/.test(userAgent)) {
        browserName = 'Opera';
        var index = userAgent.indexOf('Opera');
        if (index === -1) index = userAgent.indexOf('OPR');
        browserVersion = userAgent.substring(index + 6);
      }
      // Check for Edge
      else if (/Edge/.test(userAgent)) {
        browserName = 'Microsoft Edge';
        browserVersion = userAgent.substring(userAgent.indexOf('Edge') + 5);
      }
      // Check for Internet Explorer
      else if (/Trident/.test(userAgent)) {
        browserName = 'Internet Explorer';
        browserVersion = userAgent.substring(userAgent.indexOf('rv') + 3);
      }
      // Default to unknown
      else {
        browserName = 'Unknown';
        browserVersion = 'Unknown';
      }

      return browserName + ' ' + browserVersion;
    }
