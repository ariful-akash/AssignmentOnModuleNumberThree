function changeElement(){
    var button = document.getElementById("myButton");
    var paragraph = document.getElementById("myParagraph");

    // Add an event listener to the button element
    button.addEventListener("click", function() {
      paragraph.innerHTML = "Button clicked!";
    });
}