
function highlightParagraph() {
  var paragraph = document.getElementById("myParagraph");
  paragraph.style.backgroundColor = "yellow";
}
