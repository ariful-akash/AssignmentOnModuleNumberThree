function changeTextColor() {
    var paragraphs = document.getElementsByClassName("class-one");
    
    for (var i = 0; i < paragraphs.length; i++) {
      paragraphs[i].style.color = "red";
    }
  }
  changeTextColor();